function Login()
{
    return(
        <form >
    <table style={{width:"auto", marginLeft:"380px"}} className="table table-success table-bordered table-stripped">
        <tr>
            <td>
                Username
            </td>
            <td>
                <input type="text" placeholder="osb619"/>
            </td>
        </tr>

        <tr>
            <td>
                Password
            </td>
            <td>
                <input type="password"/>
            </td>
        </tr>

        <tr>
            <td colSpan={2}>
                <input className=" btn btn-primary" type="submit" value="Submit"/>
            </td>
        </tr>

    </table>
    
</form>
    );
}

export default Login;