function Footer(){
    return(
        <>
            <footer>Thankyou...</footer>
        </>
    );
}

export default Footer;