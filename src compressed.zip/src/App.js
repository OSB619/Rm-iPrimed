import logo from './logo.svg';
import './App.css';
import Header_Login from './Header';
import Footer from './Footer';
import Nav from './Nav';
import SingUp from './Signup';
import Login from './Login';


function App() {
  return (
    <>
    <Header_Login />
    <Nav />
    <div className='container'>
    <SingUp />
    <hr/>
    <div>
      <h1 style={{textAlign:"center"}}>Login</h1>
    </div>
    <hr/>
    <Login />
    </div>
    <Footer />
    </>
  );
}

export default App;
