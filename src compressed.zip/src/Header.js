function Header_Login(){
    return(
        <>
            <header>Login/SignUp</header>
        </>
    );
}

export default Header_Login;